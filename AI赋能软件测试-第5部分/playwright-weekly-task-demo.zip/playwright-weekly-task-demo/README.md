# Playwright UI 自动化演示：创建每周一定时任务

## 演示目标

脚本自动完成以下流程：

1. 打开 `https://autotest.wiac.xyz`
2. 使用测试账号登录
3. 进入“任务管理”
4. 点击“新建任务”
5. 创建一个“每周一”定时触发的任务
6. 保存并验证任务出现在列表中
7. 失败时保留截图、录像和 Trace

## 1. 安装依赖

```bash
npm install
npx playwright install chromium
```

## 2. 配置账号

复制环境变量文件：

```bash
# Windows PowerShell
Copy-Item .env.example .env

# macOS / Linux
cp .env.example .env
```

编辑 `.env`：

```env
BASE_URL=https://autotest.wiac.xyz
AUTOTEST_EMAIL=zhaoliu@autotest.com
AUTOTEST_PASSWORD=你的测试账号密码
TASK_NAME_PREFIX=Playwright课堂演示-每周一任务
SCHEDULE_TIME=09:00
HEADED=true
```

不要把包含真实密码的 `.env` 提交到 Git。

## 3. 执行脚本

课堂演示建议使用有头模式：

```bash
npm run test:headed
```

调试定位器：

```bash
npm run test:debug
```

查看报告：

```bash
npm run report
```

## 4. 首次运行可能需要调整的地方

由于脚本生成环境无法登录后读取平台 DOM，脚本已经兼容常见中文文案、Ant Design 和 Element Plus 的表单控件，但平台实际字段名若不同，可能需要调整以下三处正则：

```ts
/触发方式|触发类型|任务类型/i
/定时触发|定时任务|周期触发|Schedule/i
/执行周期|重复周期|周期|频率/i
```

最可靠的处理方式是运行：

```bash
npx playwright codegen https://autotest.wiac.xyz
```

手工操作一次后，把 codegen 生成的实际定位器替换到测试脚本中。

## 5. 课堂讲解重点

- AI 根据业务步骤生成的是“脚本初稿”，不是最终测试资产。
- 优先使用 `getByRole`、`getByLabel` 等语义定位器。
- 断言不能只判断“按钮点过了”，要验证任务确实创建成功。
- 失败后先区分产品、脚本、环境和数据问题，再决定是否修改代码。
- 账号密码使用环境变量管理，不写死在脚本中。
