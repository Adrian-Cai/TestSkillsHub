import { expect, Locator, Page, test } from '@playwright/test';

const email = process.env.AUTOTEST_EMAIL;
const password = process.env.AUTOTEST_PASSWORD;
const taskNamePrefix = process.env.TASK_NAME_PREFIX ?? 'Playwright课堂演示-每周一任务';
const scheduleTime = process.env.SCHEDULE_TIME ?? '09:00';

function requireEnv(name: string, value: string | undefined): string {
  if (!value) {
    throw new Error(`缺少环境变量 ${name}，请复制 .env.example 为 .env 后填写。`);
  }
  return value;
}

async function firstVisible(
  candidates: Locator[],
  description: string,
  required = true,
): Promise<Locator | null> {
  for (const candidate of candidates) {
    const count = await candidate.count().catch(() => 0);
    for (let i = 0; i < count; i += 1) {
      const item = candidate.nth(i);
      if (await item.isVisible().catch(() => false)) {
        return item;
      }
    }
  }

  if (required) {
    throw new Error(`未找到可见元素：${description}`);
  }
  return null;
}

async function fillFirst(
  candidates: Locator[],
  value: string,
  description: string,
): Promise<void> {
  const locator = await firstVisible(candidates, description);
  await locator!.fill(value);
}

async function clickFirst(
  candidates: Locator[],
  description: string,
): Promise<void> {
  const locator = await firstVisible(candidates, description);
  await locator!.click();
}

async function chooseOption(
  page: Page,
  fieldNames: RegExp,
  optionNames: RegExp,
): Promise<void> {
  // 原生 select
  const nativeSelect = await firstVisible(
    [
      page.getByLabel(fieldNames).locator('select'),
      page.getByLabel(fieldNames),
      page.locator('select').filter({ has: page.locator(`option`) }),
    ],
    `下拉框 ${fieldNames}`,
    false,
  );

  if (nativeSelect && (await nativeSelect.evaluate((el) => el.tagName === 'SELECT').catch(() => false))) {
    const options = await nativeSelect.locator('option').allTextContents();
    const matched = options.find((text) => optionNames.test(text.trim()));
    if (!matched) {
      throw new Error(`下拉框 ${fieldNames} 中没有找到选项 ${optionNames}`);
    }
    await nativeSelect.selectOption({ label: matched });
    return;
  }

  // Ant Design / Element Plus 等自定义下拉框
  const fieldContainer = page
    .locator('.ant-form-item, .el-form-item, .form-item, [class*="form-item"], [class*="field"]')
    .filter({ hasText: fieldNames })
    .first();

  const trigger = await firstVisible(
    [
      page.getByRole('combobox', { name: fieldNames }),
      fieldContainer.getByRole('combobox'),
      fieldContainer.locator('.ant-select-selector'),
      fieldContainer.locator('.el-select'),
      fieldContainer.locator('[role="combobox"]'),
    ],
    `下拉框 ${fieldNames}`,
  );

  await trigger!.click();

  const option = await firstVisible(
    [
      page.getByRole('option', { name: optionNames }),
      page.locator('.ant-select-item-option, .el-select-dropdown__item').filter({ hasText: optionNames }),
      page.getByText(optionNames, { exact: false }),
    ],
    `下拉选项 ${optionNames}`,
  );

  await option!.click();
}

async function checkMonday(page: Page): Promise<void> {
  const monday = await firstVisible(
    [
      page.getByRole('checkbox', { name: /周一|星期一|Monday/i }),
      page.getByRole('radio', { name: /周一|星期一|Monday/i }),
      page.getByRole('button', { name: /周一|星期一|Monday/i }),
      page.getByText(/^(周一|星期一|Monday)$/i),
    ],
    '周一选项',
  );

  const role = await monday!.getAttribute('role');
  const type = await monday!.getAttribute('type');
  if (role === 'checkbox' || role === 'radio' || type === 'checkbox' || type === 'radio') {
    if (!(await monday!.isChecked().catch(() => false))) {
      await monday!.check().catch(async () => monday!.click());
    }
  } else {
    await monday!.click();
  }
}

async function fillScheduleTimeIfPresent(page: Page): Promise<void> {
  const timeInput = await firstVisible(
    [
      page.getByLabel(/执行时间|触发时间|开始时间|时间/i),
      page.getByPlaceholder(/请选择.*时间|HH:mm|时间/i),
      page.locator('input[type="time"]'),
    ],
    '执行时间输入框',
    false,
  );

  if (!timeInput) return;

  await timeInput.fill(scheduleTime).catch(async () => {
    await timeInput.click();
    await timeInput.press('ControlOrMeta+A');
    await timeInput.pressSequentially(scheduleTime);
    await timeInput.press('Enter');
  });
}

async function login(page: Page): Promise<void> {
  await page.goto('/');

  await fillFirst(
    [
      page.getByLabel(/邮箱|账号|用户名|email/i),
      page.getByPlaceholder(/邮箱|账号|用户名|email/i),
      page.locator('input[type="email"]'),
      page.locator('input[name*="email" i], input[name*="username" i], input[name*="account" i]'),
    ],
    requireEnv('AUTOTEST_EMAIL', email),
    '邮箱输入框',
  );

  await fillFirst(
    [
      page.getByLabel(/密码|password/i),
      page.getByPlaceholder(/密码|password/i),
      page.locator('input[type="password"]'),
    ],
    requireEnv('AUTOTEST_PASSWORD', password),
    '密码输入框',
  );

  await clickFirst(
    [
      page.getByRole('button', { name: /登录|登\s*录|sign in|log in/i }),
      page.locator('button[type="submit"]'),
    ],
    '登录按钮',
  );

  await expect(
    page.getByText(/任务管理|控制台|工作台|首页/i).first(),
    '登录后应进入系统首页',
  ).toBeVisible();
}

test('在任务管理中新建每周一触发的定时任务', async ({ page }) => {
  const taskName = `${taskNamePrefix}-${Date.now()}`;

  await test.step('1. 登录自动化测试平台', async () => {
    await login(page);
  });

  await test.step('2. 进入任务管理页面', async () => {
    await clickFirst(
      [
        page.getByRole('menuitem', { name: /任务管理/i }),
        page.getByRole('link', { name: /任务管理/i }),
        page.getByText(/^任务管理$/),
      ],
      '任务管理菜单',
    );
    await expect(page.getByText(/任务管理/i).first()).toBeVisible();
  });

  await test.step('3. 打开新建任务表单', async () => {
    await clickFirst(
      [
        page.getByRole('button', { name: /新建任务|创建任务|新增任务|新建|新增/i }),
        page.getByText(/^(新建任务|创建任务|新增任务|新建|新增)$/),
      ],
      '新建任务按钮',
    );
  });

  await test.step('4. 填写任务名称', async () => {
    await fillFirst(
      [
        page.getByLabel(/任务名称|名称/i),
        page.getByPlaceholder(/请输入.*任务.*名称|任务名称/i),
        page.locator('input[name*="taskName" i], input[name="name"]'),
      ],
      taskName,
      '任务名称输入框',
    );
  });

  await test.step('5. 设置为每周一触发', async () => {
    await chooseOption(page, /触发方式|触发类型|任务类型/i, /定时触发|定时任务|周期触发|Schedule/i);
    await chooseOption(page, /执行周期|重复周期|周期|频率/i, /每周|按周|周|Weekly/i);
    await checkMonday(page);
    await fillScheduleTimeIfPresent(page);
  });

  await test.step('6. 保存任务并验证结果', async () => {
    await clickFirst(
      [
        page.getByRole('button', { name: /确定|保存|创建|提交/i }),
        page.locator('button[type="submit"]'),
      ],
      '保存任务按钮',
    );

    const successMessage = page.getByText(/创建成功|保存成功|操作成功|success/i).first();
    const taskRow = page.getByText(taskName, { exact: true }).first();

    await expect(successMessage.or(taskRow), '应提示创建成功，或任务列表中出现新任务').toBeVisible();
    await expect(taskRow, '任务列表中应显示新创建的任务').toBeVisible();

    await page.screenshot({
      path: `test-results/screenshots/${taskName}.png`,
      fullPage: true,
    });
  });
});
